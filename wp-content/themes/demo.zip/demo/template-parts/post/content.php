<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress

 * @since 1.0
 * @version 1.2
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<header class="entry-header">
		<div class="jws-container">
			<div class="jws-row">
				<div class="jws-col-2">
					<div class="info-author">
						<div class="author">	
							<div class="avatar-author">
								<?php echo get_avatar( get_the_author_meta( 'ID' )); ?>
							</div>
							<div class="author-name">
								<span class="by">By:</span>
								<span class="name">
									<a href="<?php esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) ?>" class="link-info-author">
										<?php echo get_the_author();?>
									</a>
								</span>
							</div>
						</div>
					</div>
				</div>
				<div class="jws-col-10">
					<?php
					if ( 'post' === get_post_type() ) {
						echo '<div class="entry-meta">';
						echo get_the_date();
						echo '<span class="mgct">/</span>';?>
						<span class="cmt">
							comments &nbsp;:&nbsp;
							<?php echo get_comments_number(); ?>
						</span>
						
						<?php
						echo '</div><!-- .entry-meta -->';
					};

					if ( is_single() ) {
						the_title( '<h1 class="entry-title">', '</h1>' );
					} elseif ( is_front_page() && is_home() ) {
						the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
					} else {
						the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
					}
					?>
				</div>
			</div>
		</div>


	</header><!-- .entry-header -->


	<div class="entry-content">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before'      => '<div class="page-links">' . __( 'Pages:', 'twentyseventeen' ),
				'after'       => '</div>',
				'link_before' => '<span class="page-number">',
				'link_after'  => '</span>',
			)
		);
		?>
		
	</div><!-- .entry-content -->


	<div class="about-author">
		<div class="container">
			<div class="row">
				<div class="clo-cts-3">
					<?php echo get_avatar( get_the_author_meta( 'ID' )); ?>
					<div class="contact-author">
						<div class="bg-contact-author">
							<ul class="list-icon">
								<li class="item"><a class="link facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
								<li class="item"><a class="link twitter" href="#"><i class="fab fa-twitter"></i></i></a></li>
								<li class="item"><a class="link google-plus" href="#"><i class="fab fa-google-plus-g"></i></i></a></li>
								<li class="item"><a class="link linkedin" href="#"><i class="fab fa-linkedin-in"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="clo-cts-9">
					<div class="description">
						<h2 class="title">About Author</h2>
						<p class="text"><?php $authorDesc = the_author_meta('description'); echo $authorDesc; ?></p>
					</div>
				</div>	
			</div>
		</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->
