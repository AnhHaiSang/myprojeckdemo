<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); jws_title_bar(); ?>

<div class="wrap">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<?php $the_query = new \WP_Query( $args );?>
			<div class="container">
				<div class="row">
					<div class="col-12 col-sm-6 col-md-6 col-lg-8 col-xl-9">
						<div class="post_thumbnail">
						 	<?php
						 		$attach_id = get_post_thumbnail_id();
						 		$img = jws_getImageBySize(array('attach_id' => $attach_id, 'thumb_size' => "870x480", 'class' => 'attachment-large wp-post-image'));
						 		echo wp_kses_post($img['thumbnail']);
						 	?>
							<div class="contact-us">
								<div class="container-contact-us">
									<ul class="list">
										<li class="item">
											<a href="#" class="contact-list">
												<span class="icon facebook">
													<i class="fab fa-facebook-f"></i>
												</span>
											</a>
										</li>
										<li class="item">
											<a href="#" class="contact-list">
												<span class="icon twitter">
													<i class="fab fa-twitter"></i>
												</span>
											</a>
										</li>
										<li class="item">
											<a href="#" class="contact-list">
												<span class="icon google-plus">
														<i class="fab fa-google-plus-g"></i>
												</span>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						 	<?php
						 	/* Start the Loop */
						 	while ( have_posts() ) :
						 		the_post();

						 		get_template_part( 'template-parts/post/content', get_post_format() );

								// If comments are open or we have at least one comment, load up the comment template.
						 		if ( comments_open() || get_comments_number() ) :
						 			comments_template();
						 		endif;

							endwhile; // End of the loop.
						?>
						
					</div>
					<aside class="col-12 col-sm-6 col-md-6 col-lg-4 col-xl-3">
						<?php  if ( is_active_sidebar( 'sidebar-1' ) ) {
                        			     dynamic_sidebar( 'sidebar-1' );
                        		   } ?>
						
					</aside>
				</div>
			</div>
		</main><!-- #main -->
	</div><!-- #primary -->

</div><!-- .wrap -->

<?php
get_footer();
