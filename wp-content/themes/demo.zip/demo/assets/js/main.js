var jwsThemeModule;
(function($){
 "use strict"; 
 jwsThemeModule = (function() {
  return {
    init: function() {
      this.search();
      this.user();
      this.hover();
      this.filtersColour();
      this.filtersSize();
    },
    // -----------------------click show/hiden search----------------
    search :function(){ 
      $('#search-call').removeClass('toggled');

      $('.jws-search').click(function(e) {
        e.stopPropagation();
        $('#search-call').toggleClass('toggled');
        $("#s").focus();
      });

      $('#search-call').click(function(e) {
        e.stopPropagation();
      });

      $('#close').click(function() {
        $('#search-call').removeClass('toggled');
      });

    },  
    // --------------click show/hiden from reigster & login---------------
    user :function(){ 
      $('#from-login').removeClass('login-show');
      $('.login').click(function(e) {
        e.stopPropagation();
        $('#from-login').toggleClass('login-show');
        $("#username").focus();
      });

      $('#customer_login').click(function(e) {
        e.stopPropagation();
      });
      $('#close-login').click(function() {
        $('#from-login').removeClass('login-show');
      });
    },  
    // --------------hover show My Acount && Logout--------------------------
    hover :function(){ 
      $(".elementor-element.elementor-element-a4871a0.elementor-column.elementor-col-20.elementor-top-column").hover(function(){
        $(".form-loged").css("display", "block");
      }, function(){
        $(".form-loged").css("display", "none");
      });
    },
    filtersColour :function(){
      $(".elementor-element.elementor-element-63e0594.elementor-widget.elementor-widget-jws_product_filter_atribute").click(function(){
        $(".jws_filter_attr").toggleClass("block");
      });
    },
    filtersSize :function(){
      $(".elementor-element.elementor-element-bea06b6.elementor-widget.elementor-widget-jws_product_filter_atribute").click(function(){
        $(".jws_filter_attr").toggleClass("block2");
      });
    }
    

  }
}())
 $(document).ready(function() {
  jwsThemeModule.init();
}); 
})(jQuery);